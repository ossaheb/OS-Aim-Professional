# OS Aim

Standalone Carrom AI practice/simulator Android project.

## Included
- OS Aim branding and supplied logo
- Interactive carrom board
- Aim line
- Local simulator AI auto-play toggle
- Activation/licensing demo
- Admin login and panel

## Build APK
Open in Android Studio, sync Gradle, then:
Build → Build Bundle(s) / APK(s) → Build APK(s)

## Scope
The AI auto-play works only inside this standalone simulator. It does not read, overlay, or control a third-party Carrom Pool game.

## Production licensing
Move admin authentication and license verification to a backend before public distribution; do not ship admin secrets inside the APK.
