package com.example.carromautoplaysimulator

import android.app.Activity
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.content.Context
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var codeInput: EditText
    private lateinit var activation: ActivationManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activation = ActivationManager(this)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(16,16,20))
        }

        val title = TextView(this).apply {
            text = "🎯 Carrom AutoPlay Simulator"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 24)
        }
        root.addView(title)

        status = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        }
        root.addView(status)

        if (activation.isActivated()) {
            status.text = "Activated • " + activation.expiryText()
            addButton(root, "Open Carrom Simulator") { openSimulator() }
            addButton(root, "Deactivate on this device") {
                activation.clear()
                showHome()
            }
        } else {
            status.text = "Activation required"
            codeInput = EditText(this).apply {
                hint = "Enter activation code"
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
                singleLine = true
            }
            root.addView(codeInput, LinearLayout.LayoutParams(-1, -2))
            addButton(root, "Activate") {
                val result = activation.activate(codeInput.text.toString())
                Toast.makeText(this, result, Toast.LENGTH_LONG).show()
                if (activation.isActivated()) showHome()
            }
        }

        addButton(root, "Admin: Generate Code") {
            showAdminDialog()
        }

        setContentView(root)
    }

    private fun addButton(root: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
    }

    private fun showAdminDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 10, 40, 10)
        }
        val key = EditText(this).apply {
            hint = "Admin key"
            inputType = 1
        }
        val days = EditText(this).apply {
            hint = "Validity days (e.g. 30)"
            inputType = 2
        }
        box.addView(key)
        box.addView(days)

        AlertDialogCompat.show(this, "Admin Code Generator", box) {
            val d = days.text.toString().toLongOrNull() ?: 30L
            val code = activation.generateAdminCode(key.text.toString(), d)
            Toast.makeText(this, code, Toast.LENGTH_LONG).show()
        }
    }

    private fun openSimulator() {
        setContentView(CarromView(this))
    }
}

object AlertDialogCompat {
    fun show(context: Context, title: String, view: LinearLayout, onOk: () -> Unit) {
        android.app.AlertDialog.Builder(context)
            .setTitle(title)
            .setView(view)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Generate") { _, _ -> onOk() }
            .show()
    }
}

class ActivationManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("activation", Context.MODE_PRIVATE)
    private val adminKey = "CHANGE_THIS_ADMIN_KEY"

    fun isActivated(): Boolean {
        val expiry = prefs.getLong("expiry", 0)
        return prefs.getBoolean("active", false) && System.currentTimeMillis() < expiry
    }

    fun activate(raw: String): String {
        val parts = raw.trim().split("-")
        if (parts.size != 3 || parts[0] != "CARROM") return "Invalid code format"
        val expiry = parts[1].toLongOrNull() ?: return "Invalid code"
        val sig = parts[2]
        if (System.currentTimeMillis() >= expiry) return "Code expired"
        val expected = Signature.make("CARROM-$expiry", "DEMO_SERVER_SECRET")
        if (sig != expected) return "Invalid activation code"
        prefs.edit().putBoolean("active", true).putLong("expiry", expiry).apply()
        return "Activation successful"
    }

    fun generateAdminCode(key: String, days: Long): String {
        if (key != adminKey) return "Admin key incorrect"
        val expiry = System.currentTimeMillis() + days * 24L * 60L * 60L * 1000L
        val payload = "CARROM-$expiry"
        return "$payload-${Signature.make(payload, "DEMO_SERVER_SECRET")}"
    }

    fun expiryText(): String =
        SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(prefs.getLong("expiry", 0)))

    fun clear() = prefs.edit().clear().apply()
}

object Signature {
    fun make(payload: String, secret: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        val bytes = md.digest((payload + secret).toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }.take(16).uppercase()
    }
}
