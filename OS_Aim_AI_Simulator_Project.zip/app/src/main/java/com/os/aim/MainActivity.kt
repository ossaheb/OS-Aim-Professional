package com.os.aim

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import android.content.Context
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var activation: ActivationManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activation = ActivationManager(this)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 24)
            setBackgroundColor(Color.rgb(7, 9, 8))
        }

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.icon_foreground)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        root.addView(logo, LinearLayout.LayoutParams(-1, 200))

        val title = TextView(this).apply {
            text = "OS AIM"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "CARROM AIM • PRACTICE SIMULATOR"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, 4, 0, 22)
        }
        root.addView(subtitle)

        if (activation.isActivated()) {
            addStatus(root, "● ACTIVATED • ${activation.expiryText()}", true)
            addButton(root, "🎯 OPEN AIM SIMULATOR") { openSimulator() }
        } else {
            addStatus(root, "● ACTIVATION REQUIRED", false)
            val code = EditText(this).apply {
                hint = "Enter activation code"
                setSingleLine(true)
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
            }
            root.addView(code, LinearLayout.LayoutParams(-1, -2))
            addButton(root, "✓ ACTIVATE OS AIM") {
                Toast.makeText(this, activation.activate(code.text.toString()), Toast.LENGTH_LONG).show()
                if (activation.isActivated()) showHome()
            }
        }

        addButton(root, "🔐 ADMIN LOGIN") { showAdminLogin() }

        val footer = TextView(this).apply {
            text = "OS Aim • Standalone Simulator"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(0, 22, 0, 0)
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun showAdminLogin() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(35, 5, 35, 5)
        }
        val username = EditText(this).apply {
            hint = "Admin username"
            setSingleLine(true)
        }
        val password = EditText(this).apply {
            hint = "Admin password"
            inputType = 0x81
            setSingleLine(true)
        }
        box.addView(username)
        box.addView(password)

        AlertDialog.Builder(this)
            .setTitle("OS Aim Admin Login")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Login") { _, _ ->
                if (activation.adminLogin(username.text.toString(), password.text.toString())) {
                    showAdminPanel()
                } else {
                    Toast.makeText(this, "Invalid admin credentials", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun showAdminPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 24)
            setBackgroundColor(Color.rgb(7, 9, 8))
        }

        val heading = TextView(this).apply {
            text = "👑 OS AIM • ADMIN PANEL"
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(0, 15, 0, 20)
        }
        root.addView(heading)

        addButton(root, "🔑 CREATE ACTIVATION CODE") {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(35, 5, 35, 5)
            }
            val days = EditText(this).apply {
                hint = "Validity days (7 / 30 / 365)"
                inputType = 2
                setSingleLine(true)
            }
            box.addView(days)
            AlertDialog.Builder(this)
                .setTitle("Create License")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Create") { _, _ ->
                    val d = days.text.toString().toLongOrNull() ?: 30L
                    val code = activation.generateAdminCode(d)
                    AlertDialog.Builder(this)
                        .setTitle("Activation Code")
                        .setMessage(code)
                        .setPositiveButton("OK", null)
                        .show()
                }.show()
        }

        addButton(root, "📋 LICENSE STATUS") {
            AlertDialog.Builder(this)
                .setTitle("License Status")
                .setMessage("Local demo license manager.\n\nProduction version should read license status from a secure server.")
                .setPositiveButton("OK", null).show()
        }

        addButton(root, "🚫 LOG OUT") { showHome() }

        setContentView(root)
    }

    private fun addStatus(root: LinearLayout, text: String, active: Boolean) {
        val t = TextView(this).apply {
            this.text = text
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(if (active) Color.rgb(170,255,80) else Color.rgb(255,180,80))
            setPadding(0, 10, 0, 8)
        }
        root.addView(t)
    }

    private fun addButton(root: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 14f
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 9 })
    }

    private fun openSimulator() {
        setContentView(CarromView(this))
    }
}

class ActivationManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("activation", Context.MODE_PRIVATE)

    // Temporary demo credentials. Change/remove these when server authentication is connected.
    private val adminUsername = "admin"
    private val adminPassword = "OSAim@2026"

    fun adminLogin(username: String, password: String): Boolean =
        username == adminUsername && password == adminPassword

    fun isActivated(): Boolean {
        val expiry = prefs.getLong("expiry", 0)
        return prefs.getBoolean("active", false) && System.currentTimeMillis() < expiry
    }

    fun activate(raw: String): String {
        val p = raw.trim().split("-")
        if (p.size != 3 || p[0] != "CARROM") return "Invalid activation code"
        val expiry = p[1].toLongOrNull() ?: return "Invalid activation code"
        if (System.currentTimeMillis() >= expiry) return "Activation code expired"
        val expected = Signature.make("CARROM-$expiry", "DEMO_SERVER_SECRET")
        if (p[2] != expected) return "Invalid activation code"
        prefs.edit().putBoolean("active", true).putLong("expiry", expiry).apply()
        return "OS Aim activated successfully"
    }

    fun generateAdminCode(days: Long): String {
        val expiry = System.currentTimeMillis() + days.coerceAtLeast(1) * 86400000L
        val payload = "CARROM-$expiry"
        return "$payload-${Signature.make(payload, "DEMO_SERVER_SECRET")}"
    }

    fun expiryText(): String =
        SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
            .format(Date(prefs.getLong("expiry", 0)))
}

object Signature {
    fun make(payload: String, secret: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        return md.digest((payload + secret).toByteArray())
            .joinToString("") { "%02x".format(it) }.take(16).uppercase()
    }
}
