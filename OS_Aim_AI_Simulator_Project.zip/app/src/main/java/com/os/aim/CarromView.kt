package com.os.aim

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class CarromView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var striker = PointF(.50f, .82f)
    private var target = PointF(.72f, .50f)
    private var aimPoint = PointF(.72f, .20f)
    private var autoPlay = false

    init { setBackgroundColor(Color.rgb(25,18,12)) }

    override fun onDraw(c: Canvas) {
        val s=min(width,height).toFloat()
        val l=(width-s)/2f; val t=(height-s)/2f+20
        val board=RectF(l,t,l+s,t+s)

        paint.style=Paint.Style.FILL
        paint.color=Color.rgb(205,157,91); c.drawRect(board,paint)
        paint.color=Color.rgb(75,42,22); paint.style=Paint.Style.STROKE
        paint.strokeWidth=14f; c.drawRect(board,paint); paint.style=Paint.Style.FILL

        listOf(PointF(l+35,t+35),PointF(l+s-35,t+35),
               PointF(l+35,t+s-35),PointF(l+s-35,t+s-35)).forEach {
            paint.color=Color.BLACK; c.drawCircle(it.x,it.y,24f,paint)
        }

        coin(c,l+s*.50f,t+s*.50f,Color.rgb(190,40,40),13f)
        coin(c,l+s*.43f,t+s*.50f,Color.WHITE,12f)
        coin(c,l+s*.57f,t+s*.50f,Color.BLACK,12f)

        val sx=l+striker.x*s; val sy=t+striker.y*s
        val ax=l+aimPoint.x*s; val ay=t+aimPoint.y*s

        paint.color=Color.rgb(125,75,230); paint.strokeWidth=5f
        c.drawLine(sx,sy,ax,ay,paint)
        paint.color=Color.WHITE; c.drawCircle(sx,sy,18f,paint)

        paint.color=Color.WHITE; paint.typeface=Typeface.DEFAULT_BOLD
        paint.textSize=30f; c.drawText("OS AIM",l+25,t+s+48,paint)
        paint.typeface=Typeface.DEFAULT
        paint.textSize=18f
        c.drawText(if(autoPlay) "AUTO-PLAY AI: ON" else "AUTO-PLAY AI: OFF",l+25,t+s+78,paint)
        c.drawText("Drag to aim • Tap to toggle AI",l+25,t+s+105,paint)
    }

    private fun coin(c:Canvas,x:Float,y:Float,color:Int,r:Float){
        paint.color=color; c.drawCircle(x,y,r,paint)
    }

    private fun bestAim(){
        // Simple simulator AI: aim toward the selected target/pocket direction.
        aimPoint=PointF(target.x, max(.04f, target.y-.32f))
        invalidate()
    }

    override fun onTouchEvent(e:MotionEvent):Boolean{
        val s=min(width,height).toFloat()
        val l=(width-s)/2f; val t=(height-s)/2f+20
        when(e.action){
            MotionEvent.ACTION_DOWN -> {
                val nx=((e.x-l)/s).coerceIn(0f,1f)
                val ny=((e.y-t)/s).coerceIn(0f,1f)
                if(ny>.65f){ striker=PointF(nx,ny); invalidate() }
                else { autoPlay=!autoPlay; if(autoPlay) bestAim(); invalidate() }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if(!autoPlay){
                    aimPoint=PointF(((e.x-l)/s).coerceIn(0f,1f),
                                     ((e.y-t)/s).coerceIn(0f,1f))
                    invalidate()
                }
                return true
            }
        }
        return true
    }
}
